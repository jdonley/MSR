global Settings
Settings.ToolboxPath        = 'M:\MSR';                                    % Location of the MSR toolbox
Settings.DependenciesPath   = 'M:\';                                       % Location of the dependencies
Settings.ChangeUserpath     = true;                                        % Set the MATLAB userpath to the toolbox path
Settings.DefaultSystemsPath = 'M:\MSR\+Current_Systems';                   % The default location to look for MSR System files